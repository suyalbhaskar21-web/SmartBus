const $ = id => document.getElementById(id);
let me = null, selectedBus = null, selectedSeat = null, registerMode = false, currentDate = new Date().toISOString().slice(0,10);
$("travelDate").min = currentDate; $("travelDate").value = currentDate;

async function api(url, options={}) {
  const res = await fetch(url, {credentials:"same-origin", headers:{"Content-Type":"application/json", ...(options.headers||{})}, ...options});
  const data = res.status === 204 ? null : await res.json().catch(()=>({message:"Unexpected server response"}));
  if (!res.ok) throw new Error(data?.message || `Request failed (${res.status})`);
  return data;
}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2800)}
function showView(name){
  ["home","bookings","admin"].forEach(v=>$(v+"View").hidden=v!==name);
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  if(name==="bookings") loadBookings(); if(name==="admin") loadAdmin();
}
document.querySelectorAll(".nav-btn").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>$(b.dataset.close).hidden=true));
$("authBtn").onclick=()=>openAuth(false);
$("switchAuth").onclick=()=>openAuth(!registerMode);
function openAuth(reg){registerMode=reg;$("authModal").hidden=false;$("authTitle").textContent=reg?"Create account":"Login";$("authName").hidden=!reg;$("authName").required=reg;$("authSubmit").textContent=reg?"Create account":"Login";$("switchAuth").innerHTML=reg?'Already registered? <button class="text-btn">Login</button>':'New here? <button class="text-btn">Create account</button>';$("switchAuth").onclick=()=>openAuth(!registerMode)}
$("authForm").onsubmit=async e=>{
 e.preventDefault();
 try{
  const body={email:$("authEmail").value,password:$("authPassword").value};
  if(registerMode)body.name=$("authName").value;
  me=await api(registerMode?"/api/auth/register":"/api/auth/login",{method:"POST",body:JSON.stringify(body)});
  $("authModal").hidden=true;updateAccount();toast("Welcome, "+me.name);loadBuses();
 }catch(err){toast(err.message)}
};
async function updateAccount(){
 if(me){$("userLabel").textContent=me.name;$("authBtn").textContent="Logout";$("adminNav").hidden=me.role!=="ADMIN";$("authBtn").onclick=async()=>{try{await api("/api/auth/logout",{method:"POST"});me=null;updateAccount();toast("Logged out")}catch(e){toast(e.message)}}}
 else{$("userLabel").textContent="Guest";$("authBtn").textContent="Login";$("adminNav").hidden=true;$("authBtn").onclick=()=>openAuth(false)}
}
async function init(){try{me=await api("/api/auth/me")}catch(e){me=null}updateAccount();loadBuses()}
$("searchBtn").onclick=loadBuses;
async function loadBuses(){
 const from=encodeURIComponent($("source").value.trim()),to=encodeURIComponent($("destination").value.trim());
 try{
  const list=await api(`/api/buses${from&&to?`?source=${from}&destination=${to}`:""}`);
  $("resultCount").textContent=`${list.length} bus${list.length===1?"":"es"} found`;
  $("busList").innerHTML=list.length?list.map(b=>`<article class="bus-card">
   <div><div class="bus-name">${esc(b.name)}</div><div class="bus-number">${esc(b.busNumber)} · ${b.totalSeats} seats</div></div>
   <div class="route"><div><strong>${esc(b.departureTime)}</strong><small>${esc(b.source)}</small></div><div class="route-line"></div><div><strong>${esc(b.arrivalTime)}</strong><small>${esc(b.destination)}</small></div></div>
   <div class="fare">₹${b.fare.toFixed(0)}<small>per seat</small></div><button class="btn btn-primary" onclick="chooseBus(${b.id})">Select seats</button></article>`).join(""):'<div class="empty">No buses found for this route. Try another city pair.</div>';
 }catch(e){$("busList").innerHTML=`<div class="empty">${esc(e.message)}. Is the Java server running?</div>`}
}
window.chooseBus=async id=>{
 if(!me){openAuth(false);toast("Please log in to book a ticket.");return}
 try{
  selectedBus=await api("/api/buses");selectedBus=selectedBus.find(b=>b.id===id);
  if(!selectedBus)throw new Error("Bus not found");
  selectedSeat=null;$("seatTitle").textContent=`${selectedBus.name} · ₹${selectedBus.fare} per seat`;
  const date=$("travelDate").value||currentDate;
  const seats=await api(`/api/buses/${id}/seats?date=${date}`);
  $("seatGrid").innerHTML=seats.map(s=>`<button type="button" class="seat ${s.available?"":"occupied"}" ${s.available?`onclick="selectSeat(${s.number},this)"`:"disabled"}>${s.number}</button>`).join("");
  $("seatModal").hidden=false;
 }catch(e){toast(e.message)}
};
window.selectSeat=(n,el)=>{document.querySelectorAll(".seat.selected").forEach(x=>x.classList.remove("selected"));selectedSeat=n;el.classList.add("selected")};
$("passengerForm").onsubmit=async e=>{
 e.preventDefault();if(!selectedSeat){toast("Please select a seat first.");return}
 try{
  const b={busId:selectedBus.id,seatNumber:selectedSeat,travelDate:$("travelDate").value||currentDate,
   passengerName:$("passengerName").value,age:$("passengerAge").value,gender:$("passengerGender").value,
   mobile:$("passengerMobile").value,paymentMode:$("paymentMode").value};
  const ticket=await api("/api/bookings",{method:"POST",body:JSON.stringify(b)});
  $("seatModal").hidden=true;showTicket(ticket);toast("Ticket booked successfully!");
 }catch(err){toast(err.message)}
};
function showTicket(b){
 $("ticketContent").innerHTML=`<p class="eyebrow">BOOKING CONFIRMED</p><h2>Your digital ticket</h2><div class="ticket"><h3>SmartBus</h3><div class="pnr">PNR: ${esc(b.pnr)}</div><div class="ticket-grid">
 ${cell("Passenger",b.passengerName)}${cell("Bus",b.busName+" ("+b.busNumber+")")}
 ${cell("From",b.source)}${cell("To",b.destination)}
 ${cell("Travel date",b.travelDate)}${cell("Seat",b.seatNumber)}
 ${cell("Mobile",b.mobile)}${cell("Fare","₹"+b.fare)}
 ${cell("Payment",b.paymentStatus)}${cell("Status",b.status)}
 </div></div>`;
 $("ticketModal").hidden=false;
}
function cell(k,v){return `<div><small>${k}</small><strong>${esc(String(v??""))}</strong></div>`}
async function loadBookings(){
 if(!me){$("myBookings").innerHTML='<div class="empty">Please log in to view your bookings.</div>';return}
 try{const list=await api("/api/bookings/mine");$("myBookings").innerHTML=list.length?list.map(b=>`<article class="booking-card"><div><strong>${esc(b.source)} → ${esc(b.destination)}</strong><p>${esc(b.busName)} · ${esc(b.travelDate)} · Seat ${b.seatNumber}</p><p>PNR: <b>${esc(b.pnr)}</b> · ₹${b.fare}</p><span class="badge ${b.status==="CANCELLED"?"cancelled":""}">${b.status}</span></div><div>${b.status==="CONFIRMED"?`<button class="btn btn-outline" onclick="cancelBooking(${b.id})">Cancel</button>`:""}</div></article>`).join(""):'<div class="empty">No bookings yet. Search a bus to get started.</div>'}
 catch(e){toast(e.message)}
}
window.cancelBooking=async id=>{if(!confirm("Cancel this ticket?"))return;try{const r=await api(`/api/bookings/${id}/cancel`,{method:"POST"});toast(r.message);loadBookings()}catch(e){toast(e.message)}};
async function loadAdmin(){
 if(!me||me.role!=="ADMIN")return;
 try{const list=await api("/api/admin/bookings");$("adminBookings").innerHTML=list.length?list.map(b=>`<p class="admin-row"><b>${esc(b.pnr)}</b> · ${esc(b.passengerName)} · ${esc(b.source)} → ${esc(b.destination)} · ${b.status}</p>`).join(""):'<div class="empty">No reservations yet.</div>'}
 catch(e){toast(e.message)}
}
$("busForm").onsubmit=async e=>{
 e.preventDefault();const f=new FormData(e.target),body=Object.fromEntries(f.entries());body.fare=Number(body.fare);body.totalSeats=Number(body.totalSeats);
 try{await api("/api/admin/buses",{method:"POST",body:JSON.stringify(body)});e.target.reset();toast("Bus added successfully");loadBuses()}catch(err){toast(err.message)}
};
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
init();
